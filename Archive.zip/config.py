import os

# 读取环境变量
EXCEL_PATH1 = "/Users/maxfeng/Downloads/qihuo_price.xlsx"
EXCEL_PATH2 = "/Users/maxfeng/Downloads/qihuo_main.xlsx"
EXCEL_PATH3 = "/Users/maxfeng/Downloads/stock_price.xlsx"
